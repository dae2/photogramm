document.addEventListener('DOMContentLoaded', function() {
    const title = document.querySelector('.fadeIn');
    title.style.animation = 'fadeIn 2s';
});
